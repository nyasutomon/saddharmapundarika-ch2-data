# Supplementary Material S1

Numerical reproduction of the revised DSH manuscript by Yasutomo Nishi,
prepared 10 October 2026. This supplement contains derived numerical scores,
identifiers and code. It contains no SMSR transcription text, facsimile images,
or text-specific legacy restoration annotations.

## What can be reproduced

Run `python scripts/analyse.py` from any working directory, using Python 3.10+
and NumPy (the reported run used Python 3.12 and NumPy 2.3.5). Default seed is
20261010 and each unit/grouping choice has its own PCG64 generator initialized
with `SeedSequence([seed, unit_index, cluster_length])`. There are 5,000 replicates
per unit and grouping choice. The observed score arrays are treated as fixed;
reweightings apply identical weights jointly to every pair. Missing scores
are not zeros. Pair-specific denominators count available weighted blocks.
An unavailable pair is omitted from a replicate median. Nearest-witness ties
within 1e-10 percentage points split their selection weight equally.

The primary check resamples individual observed blocks. Sensitivity checks
resample fixed consecutive non-overlapping groups of 2 or 4 blocks, with a
shorter final group when necessary. They preserve dependence within each group
and are NOT a claim of independence between groups. Intervals are conditional
central 95% reweighting intervals; they are not validated population confidence
intervals, probabilities of genealogy, or tests of equality between units.

Figure regeneration uses Pillow: `python scripts/draw_figures.py --font PATH
--bold-font PATH`. Supply a sans-serif font and its bold variant on your system;
the reported figures used Arial. Figures are also supplied as 600-dpi TIFFs.
Differences in font rendering do not alter the numeric analysis.

## Files and estimators

- `data/G1.npz` ... `data/Pr3.npz`: exact-symbol strict audit block scores
  (percent), pair labels/categories (NN or ON), whole-chapter block IDs,
  and a mask excluding any O row containing physical-loss markup.
- `data/Whole.npz`: independently populated exact chapter array, with all 351
  NN and 27 ON pairs. It must NOT be reconstructed by inferring missing chapter
  scores from a zero in a subunit export. Positive archived scores determine
  the reported within-unit pair masks, not this chapter mask.
- `data/metadata.json`: source hashes, numeric alignment-frame identifiers,
  archived gaps, software version, and scoring provenance.
- `results/block_pair_scores.csv`: human-readable derived per-block scores.
  Empty entries denote unavailable strict scores, not an agreement of zero.
- `results/block_gaps.csv`: 459 unit-block rows with pair coverage, whole-block
  ID, gap (missing where either category lacks usable scores), and O-loss mask.
- `results/unit_summary.csv` and `results/statistics.json`: full-precision
  estimates, percentile limits, nearest-selection shares and input hashes.
- `figures/figure1.tif`, `figure2.tif`: final standalone artwork at 600 dpi.

For a pair, the aggregate is the arithmetic mean of retained block scores.
The unit gap is median(NN pair means) minus median(ON pair means). The block
gap is median(NN scores in that block) minus median(ON scores in that block).
The median block gap is a different estimator from the unit gap. G5 half-verses
38ab through 41cd map to G5 unit blocks 1 through 8; Table 4 uses blocks 3–8.

## Provenance and limits

These are derived scores under the uniform strict audit policy, NOT outputs
newly obtained from Chihiro Mayuzumi's production program. Legacy font-symbol
counts, not approximate contractions of UTF-8 Sanskrit, were used. Corresponding
TAB fields are compared; physical-loss fields and doubly blank cleaned fields
are excluded, singly blank fields are retained as differences, and an unequal
TAB field count excludes the pair's entire block. Available field similarities
are averaged equally within blocks, then retained blocks equally within pairs.
For the exact cleaning expressions, transformation checks and original export
audit, see the archived MIT-licensed `scripts/audit.py` in Nishi (2026), release
v1.0.2, https://doi.org/10.5281/zenodo.23276190 . The metadata records its SHA-256.

The public v1.0.2 archive does not contain this new statistical analysis.
Reproducing the earlier text-to-score layer requires lawfully obtained SMSR II
transcriptions AND matching private text-specific legacy restoration spans.
The generic encoding mapping alone does not resolve all ambiguities. Those
protected inputs are deliberately absent here. `scripts/export_block_scores.py`
provides an optional private-input exporter: it checks the archived audit-source
and private input hashes before producing numerical arrays. Use its `--help`
for the paths to the archived audit repository, restored legacy files, UTF-8
transcriptions, compiled audit library, and a separate numeric output folder.
Compile the archived `scripts/lev.c` as described in that release; the exporter
never bundles or writes out transcription text. The supplied numeric arrays
make the statistics reproducible, but do not independently verify the letters
of a manuscript or all rules of the original production program.

For each unit, pair masks and coverage must accompany interpretation. This
supplement does not establish ancestry, exclusive innovations, contamination,
change of exemplar, or validity of a transcription against its facsimile.

## Rights

The author's derived numerical results, metadata, documentation, and figures
are CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/), copyright 2026
Yasutomo Nishi. Scripts are MIT licensed; see scripts/LICENSE. The separate
archived production matrices were created with Chihiro Mayuzumi's program and
are CC BY 4.0 with his permission. No permission to redistribute SMSR texts or
private text-specific restoration spans is implied by this supplement.
