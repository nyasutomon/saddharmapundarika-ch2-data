"""Render the revised figures at 600 dpi using Pillow; no textual inputs."""
from pathlib import Path
import json,csv,numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]; U=['G1','G2','G3','G4','G5','G6','Pr1','Pr2','Pr3']
R=json.loads((ROOT/'results/statistics.json').read_text())['units']
FONT='/System/Library/Fonts/Supplemental/Arial.ttf'
BOLD='/System/Library/Fonts/Supplemental/Arial Bold.ttf'
# Substitute an available font path using --font if adapting the script elsewhere.
import argparse
p=argparse.ArgumentParser();p.add_argument('--font',default=FONT);p.add_argument('--bold-font',default=BOLD);A=p.parse_args()
def font(size,bold=False):return ImageFont.truetype(A.bold_font if bold else A.font,size)
def text(d,xy,t,size=64,bold=False,anchor=None,fill='black'):d.text(xy,t,font=font(size,bold),fill=fill,anchor=anchor)
def save(im,name):
 dest=ROOT/'figures';dest.mkdir(exist_ok=True);im.save(dest/f'{name}.tif',dpi=(600,600),compression='tiff_lzw'); im.resize((1440,round(im.height*1440/im.width)),Image.Resampling.LANCZOS).save(dest/f'{name}.png',dpi=(200,200))
# Six-inch-wide figure, both panels use exactly the revised numeric estimators.
im=Image.new('RGB',(3600,2520),'white');d=ImageDraw.Draw(im)
text(d,(220,90),'(a) Recomputed group medians',74,True);text(d,(2020,90),'(b) Gap and reweighting interval',72,True)
y0=460;dy=180;ymax=y0+8*dy
X1=lambda v:350+(v-45)/55*1260
X2=lambda v:2090+v/42*1230
for tick in [50,60,70,80,90,100]:
 x=X1(tick);d.line((x,y0-130,x,ymax+100),fill='#dddddd',width=3);text(d,(x,ymax+175),str(tick),60,anchor='mt')
for tick in [0,10,20,30,40]:
 x=X2(tick);d.line((x,y0-130,x,ymax+100),fill='#dddddd',width=3);text(d,(x,ymax+175),str(tick),60,anchor='mt')
for i,u in enumerate(U):
 y=y0+i*dy;r=R[u];text(d,(255,y),u,66,anchor='rm');text(d,(1990,y),u,66,anchor='rm')
 d.ellipse((X1(r['NN_median'])-24,y-24,X1(r['NN_median'])+24,y+24),fill='black')
 x=X1(r['ON_median']);d.rectangle((x-24,y-24,x+24,y+24),fill='#999999',outline='black',width=3)
 lo,hi=r['interval_L1'];d.line((X2(lo),y,X2(hi),y),fill='black',width=6)
 for v in [lo,hi]:d.line((X2(v),y-21,X2(v),y+21),fill='black',width=5)
 x=X2(r['gap']);d.ellipse((x-23,y-23,x+23,y+23),fill='black')
 x=X2(r['export_gap']);d.rectangle((x-20,y-56,x+20,y-16),outline='#777777',width=4)
 if i==5:d.line((200,y+dy/2,3400,y+dy/2),fill='#aaaaaa',width=4)
text(d,(1010,2230),'Similarity (%)',65,anchor='mt');text(d,(2700,2230),'Gap (percentage points)',65,anchor='mt')
d.ellipse((345,2385,390,2430),fill='black');text(d,(420,2405),'Nepalese–Nepalese',56,anchor='lm')
d.rectangle((1050,2385,1095,2430),fill='#999999',outline='black',width=3);text(d,(1125,2405),'O–Nepalese',56,anchor='lm')
d.ellipse((2050,2385,2095,2430),fill='black');text(d,(2125,2405),'Recomputed',56,anchor='lm')
d.rectangle((2740,2385,2785,2430),outline='#777777',width=4);text(d,(2815,2405),'Archived gap',56,anchor='lm')
save(im,'figure1')
# Block gap strip plot: deterministic jitter; exact block counts/masks, no fitted curve.
im=Image.new('RGB',(3600,2400),'white');d=ImageDraw.Draw(im);xlo,xhi=330,3390;ylo,yhi=200,1800
Y=lambda v:yhi-(v+50)/150*(yhi-ylo)
for tick in [-40,-20,0,20,40,60,80,100]:
 y=Y(tick);d.line((xlo,y,xhi,y),fill='#222222' if tick==0 else '#dddddd',width=5 if tick==0 else 3);text(d,(xlo-40,y),str(tick),60,anchor='rm')
rows=list(csv.DictReader((ROOT/'results/block_gaps.csv').open()));rng=np.random.default_rng(20261010)
for i,u in enumerate(U):
 x=xlo+150+i*340;vals=[float(r['gap']) for r in rows if r['unit']==u and r['gap']!='']
 for v in vals:
  xx=x+rng.uniform(-75,75);yy=Y(v);d.ellipse((xx-10,yy-10,xx+10,yy+10),fill='#888888',outline='#555555',width=1)
 yy=Y(float(np.median(vals)));d.line((x-105,yy,x+105,yy),fill='black',width=8)
 text(d,(x,1880),u,64,anchor='mt');text(d,(x,1990),f'n={len(vals)}',56,anchor='mt')
 if i==5:d.line((x+170,ylo,x+170,yhi+330),fill='#aaaaaa',width=4)
text(d,(180,70),'Block gap (percentage points)',72,True)
text(d,(1800,2210),'Bars show medians of block gaps; zero marks equality of group medians.',58,anchor='mt')
save(im,'figure2')
print('Rendered two 600-dpi TIFF figures and preview PNGs.')
