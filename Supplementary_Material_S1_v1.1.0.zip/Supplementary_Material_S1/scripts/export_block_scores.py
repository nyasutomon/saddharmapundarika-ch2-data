"""Optional private-input reproduction of numerical block arrays.
Requires archived audit.py/lev.c (Nishi 2026 v1.0.2), lawfully held UTF-8 texts,
exact restored legacy files (requiring private restoration spans), and its
compiled Levenshtein library. This script distributes no protected text.
"""
from pathlib import Path
import argparse,csv,itertools,json,tempfile,os,hashlib
import numpy as np
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--audit-repo',type=Path,required=True)
p.add_argument('--transcriptions-dir',type=Path,required=True)
p.add_argument('--legacy-dir',type=Path,required=True)
p.add_argument('--lev-library',type=Path,required=True)
p.add_argument('--output-dir',type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[1];meta=json.loads((root/'data/metadata.json').read_text());f=a.audit_repo.resolve()/'scripts/audit.py'
assert hashlib.sha256(f.read_bytes()).hexdigest()==meta['audit_source_sha256'],'Wrong audit source version'
# Fail before scoring if any private source is from a different release.
for r in meta['input_inventory']:
 base=a.legacy_dir if r['mode']=='legacy' else a.transcriptions_dir
 assert hashlib.sha256((base/r['file']).read_bytes()).hexdigest()==r['sha256'],f"Input hash mismatch: {r['mode']} {r['unit']}"
os.environ['ASCJ_TRANSCRIPTIONS_DIR']=str(a.transcriptions_dir.resolve());os.environ['ASCJ_AUDIT_LIBRARY']=str(a.lev_library.resolve())
s=f.read_text().split('results=[];summaries=[]')[0]
assert "SOURCE=REPO/'work/legacy'" in s and "ROOT=REPO/'results/recomputed'" in s
with tempfile.TemporaryDirectory() as tmp:
 s=s.replace("SOURCE=REPO/'work/legacy'",'SOURCE=Path('+repr(str(a.legacy_dir.resolve()))+')')
 s=s.replace("ROOT=REPO/'results/recomputed'",'ROOT=Path('+repr(tmp)+')')
 g={'__file__':str(f),'__name__':'export_private_scores'};exec(compile(s,str(f),'exec'),g)
 N=[x for x in g['pairlabels'] if x not in {'D1','D2','D3','O','F','M'}];order={x:i for i,x in enumerate(g['pairlabels'])};NN=list(itertools.combinations(N,2));ON=[tuple(sorted(['O',x],key=order.get)) for x in N]
 out=a.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
 for u in ['G1','G2','G3','G4','G5','G6','Pr1','Pr2','Pr3','Whole']:
  bs=g['B']['legacy'][u];nn=NN if u=='Whole' else [x for x in NN if g['M'][u][x[0]][x[1]]>0];on=ON if u=='Whole' else [x for x in ON if g['M'][u][x[0]][x[1]]>0];ps=nn+on
  ids=[b.get('whole',b['ord']) for b in bs]
  X=np.array([[g['cache']['legacy',k,*pair][0] if g['cache']['legacy',k,*pair][0] is not None else np.nan for pair in ps] for k in ids])*100
  bg=np.nanmedian(X[:,:len(nn)],axis=1)-np.nanmedian(X[:,len(nn):],axis=1)
  cm=np.array(['<LAC' not in b['rows']['O'] and bool(g['clean_legacy'](b['rows']['O'])) for b in bs])&np.isfinite(bg)
  if u=='Whole':cm=np.ones(len(bs),dtype=bool) # Whole uses no O-complete sensitivity mask.
  np.savez_compressed(out/f'{u}.npz',scores=X,pair1=np.array([p[0] for p in ps]),pair2=np.array([p[1] for p in ps]),group=np.array(['NN']*len(nn)+['ON']*len(on)),whole_block_ids=np.array(ids),O_complete_mask=cm)
print('Exported numerical arrays only; no transcription texts were copied.')
