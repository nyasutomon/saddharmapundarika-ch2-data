"""Reproduce revised-manuscript statistics from numeric derived block scores.
Requires Python 3.10+ and NumPy; no SMSR text or private encoding spans.
Intervals describe sensitivity to reweighting these observed blocks.
"""
from pathlib import Path
import argparse,csv,json,hashlib,warnings
import numpy as np
warnings.filterwarnings('ignore', message='All-NaN slice encountered')
ROOT=Path(__file__).resolve().parents[1]
UNITS=['G1','G2','G3','G4','G5','G6','Pr1','Pr2','Pr3','Whole']
def mean_cols(X):
 n=np.isfinite(X).sum(axis=0)
 return np.divide(np.nansum(X,axis=0),n,out=np.full(X.shape[1],np.nan),where=n>0)
def summarise(X,groups):
 v=mean_cols(X)
 a=v[groups=='NN']; b=v[groups=='ON']
 return float(np.nanmedian(a)-np.nanmedian(b)),a,b

def bootstrap(X,groups,seed,index,cluster,B):
 # Fixed consecutive groups (length 1, 2, or 4); the final group can be shorter.
 # Resample as many groups as observed, applying identical weights to all pairs.
 n=len(X); bins=np.arange(n)//cluster; k=int(bins[-1]+1)
 group_sum=np.zeros((k,X.shape[1])); group_count=np.zeros_like(group_sum)
 np.add.at(group_sum,bins,np.nan_to_num(X));np.add.at(group_count,bins,np.isfinite(X))
 rng=np.random.default_rng(np.random.SeedSequence([seed,index,cluster]))
 w=rng.multinomial(k,np.full(k,1/k),size=B)
 num=w@group_sum; den=w@group_count
 v=np.divide(num,den,out=np.full(num.shape,np.nan),where=den>0)
 nn=v[:,groups=='NN'];on=v[:,groups=='ON']; g=np.nanmedian(nn,axis=1)-np.nanmedian(on,axis=1)
 return g,on,nn

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--seed',type=int,default=20261010);parser.add_argument('--replicates',type=int,default=5000);args=parser.parse_args()
 out=ROOT/'results';out.mkdir(exist_ok=True);rows=[];blocks=[];samples={};allres={};manifest={}
 meta=json.loads((ROOT/'data/metadata.json').read_text());export={r['unit']:r['export_gap'] for r in meta['units']}
 for i,u in enumerate(UNITS):
  file=ROOT/f'data/{u}.npz';manifest[file.relative_to(ROOT).as_posix()]=hashlib.sha256(file.read_bytes()).hexdigest(); z=np.load(file,allow_pickle=False)
  X=z['scores'];groups=z['group'];g,a,b=summarise(X,groups)
  raw=np.nanmedian(X[:,groups=='NN'],axis=1)-np.nanmedian(X[:,groups=='ON'],axis=1);mask=np.isfinite(raw)
  row={'unit':u,'blocks':len(X),'NN_pairs':len(a),'ON_pairs':len(b),'NN_median':float(np.nanmedian(a)),'ON_median':float(np.nanmedian(b)),'gap':g,'export_gap':export.get(u),'valid_block_gaps':int(mask.sum()),'nonpositive_blocks':int(np.count_nonzero(raw[mask]<=0))}
  for cluster in [1,2,4]:
   bg,on,nn=bootstrap(X,groups,args.seed,i,cluster,args.replicates)
   row[f'interval_L{cluster}']=np.nanquantile(bg,[.025,.975]).tolist()
   row[f'finite_replicates_L{cluster}']=int(np.isfinite(bg).sum())
   if cluster==1:
    samples[u]=bg
    names=[p2 if p1=='O' else p1 for p1,p2 in zip(z['pair1'][groups=='ON'],z['pair2'][groups=='ON'])]
    row['point_nearest']=names[int(np.nanargmax(b))]
    # Fractional selection for ties within 1e-10 percentage points; unavailable
    # resampled pairs are never selected. This is conditional ranking stability.
    top=np.nanmax(on,axis=1);ties=np.isfinite(on)&np.isclose(on,top[:,None],atol=1e-10,rtol=0)
    shares=(ties/ties.sum(axis=1)[:,None]).mean(axis=0)
    row['nearest_selection_shares']=dict(zip(names,map(float,shares)))
    j=int(np.argmax(shares));row['modal_nearest']=names[j];row['modal_share']=float(shares[j])
    if u=='Whole':row['complete_nonoverlap_share']=float(np.mean(np.nanmax(on,axis=1)<np.nanmin(nn,axis=1)))
  if u!='Whole':
   cm=mask&z['O_complete_mask']; row['O_complete_blocks']=int(cm.sum());row['O_complete_nonpositive']=int((raw[cm]<=0).sum())
   for j,bid in enumerate(z['whole_block_ids']):
    blocks.append({'unit':u,'unit_block':j+1,'whole_block':int(bid),'NN_valid_pairs':int(np.isfinite(X[j,groups=='NN']).sum()),'ON_valid_pairs':int(np.isfinite(X[j,groups=='ON']).sum()),'gap':float(raw[j]) if mask[j] else None,'O_without_LAC':bool(z['O_complete_mask'][j])})
  rows.append(row);allres[u]=row
 total=sum(r['valid_block_gaps'] for r in rows if r['unit']!='Whole');nonpos=sum(r['nonpositive_blocks'] for r in rows if r['unit']!='Whole')
 result={'seed':args.seed,'replicates':args.replicates,'numpy_version':np.__version__,'bit_generator':'PCG64 via SeedSequence([seed,unit_index,cluster_length])','units':allres,'valid_blocks_total':total,'nonpositive_total':nonpos,'nonpositive_percent':100*nonpos/total,'G5_minus_G1_point':allres['G5']['gap']-allres['G1']['gap'],'G5_minus_G1_L1_interval':np.quantile(samples['G5']-samples['G1'],[.025,.975]).tolist(),'O_complete_total':sum(r.get('O_complete_blocks',0) for r in rows),'O_complete_nonpositive':sum(r.get('O_complete_nonpositive',0) for r in rows),'input_sha256':manifest}
 (out/'statistics.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 fields=['unit','blocks','NN_pairs','ON_pairs','NN_median','ON_median','gap','export_gap','valid_block_gaps','nonpositive_blocks','point_nearest','modal_nearest','modal_share']
 for L in [1,2,4]:fields.extend([f'L{L}_lo',f'L{L}_hi'])
 with (out/'unit_summary.csv').open('w',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader()
  for r in rows:
   d={k:r[k] for k in fields if k in r}
   for L in [1,2,4]:d[f'L{L}_lo'],d[f'L{L}_hi']=r[f'interval_L{L}']
   wr.writerow(d)
 with (out/'block_gaps.csv').open('w',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=list(blocks[0]));wr.writeheader();wr.writerows(blocks)
 # Human-readable numeric score table, with missing entries explicitly blank.
 with (out/'block_pair_scores.csv').open('w',newline='') as f:
  wr=csv.writer(f);wr.writerow(['unit','unit_block','whole_block','group','witness1','witness2','score_percent'])
  for u in UNITS[:-1]:
   z=np.load(ROOT/f'data/{u}.npz',allow_pickle=False)
   for j,bid in enumerate(z['whole_block_ids']):
    for k,(p1,p2,grp) in enumerate(zip(z['pair1'],z['pair2'],z['group'])):
     v=z['scores'][j,k];wr.writerow([u,j+1,int(bid),grp,p1,p2,format(v,'.17g') if np.isfinite(v) else ''])
 print(json.dumps({k:v for k,v in result.items() if k!='input_sha256' and k!='units'},indent=2))
 for r in rows:print(r['unit'],round(r['gap'],3),[round(v,2) for v in r['interval_L1']], 'L2', [round(v,2) for v in r['interval_L2']], 'L4',[round(v,2) for v in r['interval_L4']],r['point_nearest'],r['modal_nearest'],round(r['modal_share'],3))
if __name__=='__main__':main()
